clear;
%% User settings
%do you want to limit x and y stable? 0 -> yes; 1 -> no;
Anse = 1; 

% Trajectory
t = (0:0.01:10)'; 

x_init = [0;0;1; 0;0;0; 0;0;0; 0;0;0]; %initial state of UAV
r_pos = zeros(length(t), 1); %position trajectory
r_pos(:,1) = 1;

r_att = zeros(length(t), 3); %desired attitude
r_att(:,1) =pi/6 * (t >= 1); %roll
r_att(:,2) =pi/9 * (t >= 1); %yaw
r_att(:,3) =pi/3 * (t >= 5); %pitch

ref_signal.time = t;  
ref_signal.signals.values = [r_pos, r_att];
ref_signal.signals.dimensions = 4; 

assignin('base', 'ref_signal', ref_signal);

%% modelling
m = 1.325; % kg
I = [0.053 0.053 0.098];% rotational inertia， kg/m^2
g = 9.8;

%x: x y z phi theta psi xd yd zd phid thetad psid
%u: ut ux uy uz
%y: x y z phi theta psi
A = zeros(12,12);
A(1:6,7:12) = eye(6);
A(8,4) = g;
A(7,5) = -g;

B = zeros(12,4);
B(9,1) = -1/m;
B(10,2) = 1/I(1);
B(11,3) = 1/I(2);
B(12,4) = 1/I(3);

C = zeros(6,12);
C(1:3,1:3) = eye(3);
C(4:6,4:6) = eye(3);

con = ctrb(A,B);
rank_con = rank(con);
obs = obsv(A, C);
rank_obs = rank(obs);

%% reduced order observer
%build reduced-order observer
T = zeros(6,12);
T(1:3,7:9) = eye(3);
T(4:6,10:12) = eye(3);
P = [C;T];

%Get unmeasureable part of A and B
PAP = P*A*inv(P);
A_11 = PAP(1:6,1:6);
A_12 = PAP(1:6,7:12);
A_21 = PAP(7:12,1:6);
A_22 = PAP(7:12,7:12);
PB = P*B;
B_1 = PB(1:6,:);
B_2 = PB(7:12,:);
D = 0;

% Observer pole
polevec_L = [-20,-25,-30,-35,-40,-45];
L = place(A_22',A_12',polevec_L)';



%% BUILD REDUCED + AUGMENTED CONTROLLER and map to K / Ka 
% Full state order assumed: [x y z phi theta psi xd yd zd phid thetad psid]
% Indices for z,phi,theta,psi and their derivatives:
idx = [3 4 5 6 9 10 11 12];  % 8 states

A_sub = A(idx, idx);
B_sub = B(idx, :);   % 8x4 and 4 inputs (Ut, Ux, Uy, Uz)

% C_sub: outputs we want integrators for (z, phi, theta, psi) -> map to A_sub ordering
C_sub = [eye(4) zeros(4,4)];   % 4x8 (z,phi,theta,psi are first 4 states in A_sub)

% Augment with 4 integrators
n_sub = size(A_sub,1);   % 8
n_int = size(C_sub,1);   % 4

A_aug_sub = [A_sub, zeros(n_sub, n_int);
             -C_sub, zeros(n_int, n_int)];
B_aug_sub = [B_sub;
             zeros(n_int, size(B_sub,2))];

% --- Controllability check
Co = ctrb(A_aug_sub, B_aug_sub);
rankCo = rank(Co);
if rankCo < size(A_aug_sub,1)
    warning("Reduced augmented system NOT fully controllable: %d / %d", rankCo, size(A_aug_sub,1));
    % Print useful diagnostics
    [At,Bt,Ct,T,k] = ctrbf(A_aug_sub, B_aug_sub, eye(size(A_aug_sub,1)));
    fprintf("Controllable dim = %d. Uncontrollable eigenvalues:\n", k);
    disp(eig(At(k+1:end,k+1:end)));
    % You can decide to remove some integrators or investigate B_sub
end

% --- Choose pole vector (try to be conservative / well-spaced)
try
    % recommended: inner attitude faster than altitude - but here we pick a safe spread
    polevec = [-2 -2.5 -3 -3.5 -4 -4.5 -5 -5.5 -6 -6.5 -7 -8]; % length 12 (8+4)
    if length(polevec) ~= (n_sub + n_int)
        polevec = linspace(-2, -9, n_sub + n_int);
    end

    % Attempt placement
    K_aug_sub = place(A_aug_sub, B_aug_sub, polevec);

catch ME_place
    % fallback: spread poles slower and try again
    warning('place failed once (%s). Trying a slower spread ME_place.message');
    polevec = linspace(-1, -6, n_sub + n_int);
    K_aug_sub = place(A_aug_sub, B_aug_sub, polevec);
end

% Extract gains for reduced subsystem
K_sub = K_aug_sub(:, 1:n_sub);      % 4 x 8
Ki_sub = K_aug_sub(:, n_sub+1:end); % 4 x 4  (integrator gains for z,phi,theta,psi)

% Map to original 12-state K (4 x 12) so Simulink can use the same variable names
K = zeros(4, 12);
K(:, idx) = K_sub;   % place K_sub columns at the indices corresponding to the selected states

% Ka used previously as integrator gain: keep shape consistent (4 x 4)
Ka = Ki_sub;

% Export to base workspace for Simulink
assignin('base', 'K', K);
assignin('base', 'Ka', Ka);

% For debugging print small summary
fprintf('K size: %dx%d, Ka size: %dx%d\n', size(K,1), size(K,2), size(Ka,1), size(Ka,2));


%% wind disturbance (not applied here)
ref_suddenwind = zeros(length(t), 3);
ref_suddenwind(:,1) = 0;         % sudden wind
ref_suddenwind(50:150,2) = 0;    
ref_suddenwind(:,3) = 0;              

suddenwind.time = t;
suddenwind.signals.values = ref_suddenwind;
suddenwind.signals.dimensions = 3;        

assignin('base', 'suddenwind', suddenwind);

ref_bgw = zeros(length(t), 4);
ref_bgw(:,1) = 0;         % background wind
ref_bgw(:,2) = 0;    
ref_bgw(:,3) = 0;              
ref_bgw(:,4) = 0;  

bgw.time = t;
bgw.signals.values = ref_bgw;
bgw.signals.dimensions = 4;        

assignin('base', 'bgw', bgw);

%% run simulation, get the pre-timeseries of 6 values
sim("simu.slx")

%% create animation
%organize value
time = simout.Time;
x = simout.Data(1,:);
y = simout.Data(2,:);
z = simout.Data(3,:);
phi = simout.Data(4,:);
theta = simout.Data(5,:);
psi = simout.Data(6,:);

%build timeseries
traj_x = timeseries(x, time, 'Name', 'X_Position');
traj_y = timeseries(y, time, 'Name', 'Y_Position');
traj_z = timeseries(z, time, 'Name', 'Z_Position');
traj_phi = timeseries(phi, time, 'Name', 'Roll');
traj_theta = timeseries(theta, time, 'Name', 'Pitch');
traj_psi = timeseries(psi, time, 'Name', 'Yaw');

% run uav simulation, show animation
sim("uav_animation.slx")